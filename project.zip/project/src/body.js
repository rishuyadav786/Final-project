import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './home';



class Body extends Component {
  render() {
    return (
      <div className="container">


        <div className="col-md-4 ">
          This is Profile page...
          <img src={logo} height="250px;"></img>
     </div>
        <div className="col-md-6">

          <Home /><br/>
          <Home /><br/>
          <Home /><br/>
          <Home />
        </div>
      </div>
    );
  }
}


export default Body;
