var expect = require("chai").expect;

var should = require("chai").should();
var assert = require("chai").assert;
var _ = require("lodash");
var { getData } = require("../app/index");

describe.only("Testing async methods", () => {
    it("expect getData() returns Hello", (done) => {
        var result;
        getData()
            .then(res => {
                result = res;
                expect(result).to.be.equal("Hello");
                done();
            });
    })
})