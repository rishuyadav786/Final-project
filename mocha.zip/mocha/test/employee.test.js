// var expect=require("chai").expect;

// var should=require("chai").should();
// var assert=require("chai").assert;
// var Employee=require("../app/employee");
// var _=require("lodash");
// // describe.only("#Employee class test",()=>{// if we use only .. then it is executed not other function...
//     describe("#Employee class test",()=>{
//     describe("#Testing constructor ",()=>{
//         it(" Employee(name,age)should initialize members with default values",()=>{
//             var emp=new Employee("ajay",30);
//             // emp.name.should.be.equal("");
//             expect(emp.name).to.be.equal("ajay");
//             emp.age.should.be.equal(30);

//         });
//         describe.only("Testing employee objects",()=>{
//             it("should return the name of employee",()=>{
//                 var emp=new Employee("ajay",30);
         
//                 expect(emp.getName()).to.be.equal("ajay");
//                 // emp.age.should.be.equal(30);
//             });
//             it("age should be a finite number",()=>{
//                 var emp=new Employee("ajay",30);
         
//                 _.isFinite(emp.age).should.be.true;
//                 // emp.age.should.be.equal(30);
//             });
//         })
//     })
// })

// ////  "test": " mocha ./test/calculator.test.js"
















//life cycle hook beforeEach and afterEach...





var expect=require("chai").expect;

var should=require("chai").should();
var assert=require("chai").assert;
var Employee=require("../app/employee");
var _=require("lodash");
// describe.only("#Employee class test",()=>{// if we use only .. then it is executed not other function...
    describe("#Employee class test",()=>{
    describe("#Testing constructor ",()=>{
        var emp;
        before(()=>{
            console.log("before all");
            emp=new Employee("ajay",40);
        })
        beforeEach(()=>{
            console.log("before each");
            // emp=new Employee("ajay",40);
        })
        afterEach(()=>{
            console.log("after each");
            
        })
        after(()=>{
            emp=new Employee("",0);
            console.log("after all");
            
        })
    
        it(" Employee(name,age)should initialize members with default values",()=>{
          
            // emp.name.should.be.equal("");
            expect(emp.name).to.be.equal("ajay");
            emp.age.should.be.equal(30);

        });
        describe.only("Testing employee objects",()=>{
            it("should return the name of employee",()=>{
                
         
                expect(emp.getName()).to.be.equal("ajay");
                // emp.age.should.be.equal(30);
            });
            it("age should be a finite number",()=>{
             
         
                _.isFinite(emp.age).should.be.true;
                // emp.age.should.be.equal(30);
            });
        })
    })
})

////  "test": " mocha ./test/calculator.test.js"