var expect=require("chai").expect;

var should=require("chai").should();
var assert=require("chai").assert;
var {add,division,sub} =require("../app/calculator");


describe("#Testing Calculator class",()=>{


    it("sample test",()=>{
        // expect(true).to.be.true;
        // false.should.be.true;// only for should
        // true.should.be.true;


        assert(true===true, "this is not equal to false")
    })
    it("should return the sum of two number",()=>{
        var sum=add(2,4);
        expect(sum).to.be.equal(6);
    })
    it("should return the sub of two number",()=>{
        var sum1=sub(8,4);
        expect(sum1).to.be.equal(4);
    })
    it("should return the division of two number",()=>{
        var q=division(8,4);
        q.should.be.equal(2);
    })
})