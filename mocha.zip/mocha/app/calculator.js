exports.add = (a, b) => a + b;
exports.multiply = (a, b) => a * b;
exports.sub = (a, b) => a - b;
exports.division = (a, b) => a / b;