export class Register {
    name:string;
    email:string;
    username:string;
    password:string;
    repassword:string;
}
