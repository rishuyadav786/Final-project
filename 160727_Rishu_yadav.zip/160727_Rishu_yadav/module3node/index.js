var fs = require("fs");
var express = require("express");
var appBody = require("body-parser");
var app = express();
app.use(appBody.json());
var router = express.Router();


//create and run the server at port 5006
app.listen(5006, function (err, res) {
    if (err) {
        console.log("error in starting the server");
    }
    else {
        console.log("server staeted a 5006")
    }
})
var file = fs.readFileSync("mobile.json");//read file grom mobile.json..
var jsonFile = JSON.parse(file);
console.log("All data from mobile json");
console.log(JSON.stringify(jsonFile.mobile));//show all mobile in console in json formate..
console.log("updating mobile name based on mobile id-1002");
app.get("http://localhost:3000/mobile",(req,res)=>{
    
});
console.log("Adding the new mobile");
console.log("Displaying mobile belonging to a specific price range");
//show the mobile data in specific range..greater than 10000 and less than 50000
fs.readFile("mobile.json", function (err, data) {
    if (err) {
        console.log("Error in reading the file");
    }
    else {
        var allData = [];
        allData = JSON.parse(data);
        for (let i in allData.mobile) {
            if (allData.mobile[i].mobPrice > 10000 && allData.mobile[i].mobPrice < 50000) {
                console.log(allData.mobile[i]);
            }
        }
    }
})


