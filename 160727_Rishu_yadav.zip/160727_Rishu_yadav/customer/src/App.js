import React, { Component } from 'react';
import './App.css';
import Addproduct from './addproduct';
import ShowProduct from './showproduct';

class App extends Component {
  constructor(){
  super();
  this.state={
    custData:[]
  }
  }
  //code for adding the product...
  addProduct(data){
    let olddata=this.state.custData
    olddata.push(data)
    this.setState({
      custData:olddata
    })
  }
  //code for deleting or repalcing the product...
  replaceProduct(data,id)
  { 
    let olddata=this.state.custData
    olddata.splice(id,1,data)
    this.setState({
      custData:olddata
    })    
  }
 
  
  render() {

    return (
      <div className="App">       
      <Addproduct getData={this.addProduct.bind(this)}/> 
      <ShowProduct  pobject={this.state.custData} pobject1={this.replaceProduct.bind(this)}/>
      </div>
    );
  }
}

export default App;
