import React, { Component } from 'react';

class ShowProduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    delete(id) {
        this.setState({
            abc: this.props.pobject.splice(id, 1)
        });
    }

//creating show customer visit information...
    render() {
        const myListData = (<div className="container-fluid data">
            {this.props.pobject.map((data, key) =>
                <p key={data.custId} >
                Name : {data.custId}
                <br/>
                Email ID : {data.custName}
                <br/>
                Mobile Number : {data.custMobile}
                <br/>
                Address : {data.addr}
                <br/>
                Description/Purpose: {data.description}
                <br />
                Date of Visit : {data.date}
                <br/>
                    {<button onClick={this.delete.bind(this, key)}>
                        Delete
    </button>}  </p>
            )}</div>);

        return (
            <div>
                <h3>Customer Visit Information</h3>
                {myListData}
                </div>
        );
    }
}
    export default ShowProduct;