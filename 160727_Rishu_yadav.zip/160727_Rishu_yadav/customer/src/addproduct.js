import React, { Component } from 'react';

class Addproduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    getAllProduct() {
        this.setState({
            data:
            {
                custId: this.refs.custEmail.value,
                custName: this.refs.custName.value,
                custMobile: this.refs.custMobile.value,
                addr:this.refs.addr.value,
                description:this.refs.description.value,
                date:this.refs.date.value
            }
        }, function () {
            this.props.getData(this.state.data);
        }
        )
        this.refs.custEmail.value = "";
        this.refs.custName.value = "";
        this.refs.custMobile.value = "";
        this.refs.addr.value="";
        this.refs.description.value="";
        this.refs.date.value="";
    }
//creating customer registration form.....
    render() {
        return (
            <div>
                <div>
                    
                    <div className="container-fluid">
                    <div className="myForm">
                    <div className="form">
                    <h2>Customer Registration Form</h2><hr/>
                 
                            <input type="text" ref="custName"  placeholder="Username" className="form-control"/>
                            <input type="text" ref="custEmail"  placeholder="Email id" className="form-control"/>
                           <input type="text" ref="custMobile"  placeholder="Mobile Number" className="form-control" />
                            <input type="text" ref="addr"   placeholder="Address" className="form-control"/>
                           <input type="text" ref="description"  placeholder="Purpose of visit"  className="form-control" />
                            <input type="text" ref="date"   placeholder="date of visit" className="form-control"/> <br/>
                            <button onClick={this.getAllProduct.bind(this)} className="btn btn-success" >Log In</button>
                     
                    </div>
                    </div>
                    </div>
                </div>
                </div>
        );
    }
}
export default Addproduct;