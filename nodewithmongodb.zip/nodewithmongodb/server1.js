const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const path=require("path");
const cors=require("cors");
const commonRoutes=require("./routes/common-routes");
const productRoutes=require("./routes/product-routes");
const productApiRoutes=require("./routes/product-api");

//create express app object
//the midleware

var app = express();
app.set("views","views");
app.set("view engine","pug");
app.use(cors());//it allow all connection...and it is use for testing
// app.use(cors({origin:"synergetics.com/",method:["GET","POST"]})); //it is for restricted connection
app.use(express.static(path.resolve(__dirname,"public")));


app.use(cookieParser("mysecretKey"));
app.use(session({
    name: "session",
    resave: true,
    saveUninitialize: false,
    secret: "mysecretsessionkey"
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
//configure routes
app.use("/",commonRoutes);
app.use("/products",productRoutes);
app.use("/api/products",productApiRoutes);
module.exports = app;
