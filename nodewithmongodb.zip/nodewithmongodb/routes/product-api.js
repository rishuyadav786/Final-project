//product-api.js
var express = require("express");
var Product = require("../model/product-model");
var router = express.Router();

//get /api/products
router.get("", (req, res) => {
    Product.find((err, result) => {
        if (err) {
            res.status(500)
                .header("Content-Type", "application/json").json({ products: undefined });
        }
        else {
            res.status(200).header("Content-Type", "application/json").json({ products: result });
        }
    })
});
router.get("/:name", (req, res) => {

var searchValue=req.params.name;
Product.findOne({name:searchValue},(err,result)=>{
    if (err) {
        res.status(500)
            .header("Content-Type", "application/json").json({ products: undefined });
    }
    else {
        res.status(200).header("Content-Type", "application/json").json({ products: result });
    }
})
});
//POST/api/products/
router.post("", (req, res) => {
    var product=new Product(req.body);
    product.save((err, result) => {
        if (err) {
            console.log(err);
            res.status(500)
                .header("Content-Type", "application/json").json({status:false});
        }
        else {
            res.status(201).header("Content-Type", "application/json").json({status:true, products: result });
        }
    })
});

//PUT/api/products/:name
router.put("/:name", (req, res) => {

    Product.updateOne({name:req.params.name},{
        $set:{
            price:req.body.price,
            quantity:req.body.quantity
        }
    },(err,result)=>{
        if (err) {
            console.log(err);
            res.status(500)
                .header("Content-Type", "application/json").json({status:false});
        }
        else {
            res.status(200).header("Content-Type", "application/json").json({status:true, products: result });
        }
    })
    
});


//PUT/api/products/:name
router.delete("/:name", (req, res) => {

    Product.deleteOne({name:req.params.name},(err)=>{
  
        if (err) {
            console.log(err);
            res.status(500)
                .header("Content-Type", "application/json").json({status:false});
        }
        else {
            res.status(200).header("Content-Type", "application/json").json({status:true,message:"deleted" });
        }
    })
    
});



module.exports=router;