
var fs = require("fs");

var contents = fs.readFileSync("mobile.json");
var jsonContent = JSON.parse(contents);
console.log("Displaying all data from mobile.json")
console.log(JSON.stringify(jsonContent.mobile));


// var jsonObj = require("./mobile.json");
// console.log("Displaying all data from mobile.json")
// console.log(JSON.stringify(jsonObj));



// console.log("Deleting mobile based on id Default mobId is 1002")
// var removeId = 1002;
// var id = jsonContent.mobile;
// jsonContent.mobile = id.filter((mobile) => { return mobile.mobId !== removeId });
// console.log(jsonContent.mobile);

console.log("\nUpdating mobile name based on id Default mobId is 1002")

console.log("\nAdding the value in mobile.json");
// app.post("mobile.json", function () {
//     console.log("sss");
//     var mobdata = {
//         "mobId": 1006,
//         "mobName": "MI",
//         "mobPrice": 15000,
//     };
 //  console.log("Mobile data after adding new mobile : "+mobdata.mobId);
//     fs.readFile("mobile.json", function(readerr,readdata){
//         if(readerr){
//             console.log("err in reading");
//         }
//         else{
//             var allData=[];
//             allData=JSON.parse(readdata);
//            // allData.push(mobdata);
//             data_json=JSON.stringify(allData);
//             fs.writeFile("mobile.json", data_json, function(writeerr){
//                 if(writeerr)
//                 {
//                     console.log("err in write");
//                 }
//                 else{
//                     console.log("sss");
//                     console.log(data_json);
//                 }
//             });
//         }
//     });
//  });

console.log("\n Displaying mobiles belonging to a specific price range from 10,000 to 50,000");

fs.readFile("mobile.json", function (readerr, readdata) {
    if (readerr) {
        console.log("err in reading");
    }
    else {
        var allData = [];
        allData = JSON.parse(readdata);
        for (let i in allData.mobile) {
            if (allData.mobile[i].mobPrice > 10000 && allData.mobile[i].mobPrice < 50000) {
                console.log(allData.mobile[i]);
            }
        }
    }
});