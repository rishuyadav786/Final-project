export class Product {
    id:number;
    proName:string;
    prodescription:string;
    price:number;
    ram:number;
    rom:number;
    battery:number;
    processor:number;
    length:number;
    color:string;
    extra:string;
    category:string;
}
