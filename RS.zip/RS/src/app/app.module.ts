import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgxPaginationModule} from 'ngx-pagination';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { FormsModule} from '@angular/forms';
import {approutingmodule,routingComponent} from './approutingmodule';
import{HttpModule} from '@angular/http';
import { ProductserveService } from './productserve.service';
import { ShowComponent } from './show/show.component';
// import { AddComponent } from './add/add.component';
// import { EditComponent } from './edit/edit.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,routingComponent, ShowComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule,NgxPaginationModule,approutingmodule,HttpModule
  ],
  providers: [ProductserveService],
  bootstrap: [AppComponent]
})
export class AppModule { }
