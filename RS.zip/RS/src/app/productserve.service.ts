import { Injectable, Output, EventEmitter } from '@angular/core';
import { Product } from './product';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
@Injectable()
export class ProductserveService {
  products: Product[] = [];
  product: Product = new Product();
  @Output() showProduct:EventEmitter<Product>=new EventEmitter<Product>();

  constructor(private http: Http) { }

  addpro(pro: Product): Observable<Product[]> {
    return this.http.post("http://localhost:3000/prod", pro).map((response: Response) => <Product[]>response.json());
  }

  getProduct(): Observable<Product[]> {
    return this.http.get("http://localhost:3000/prod").map((response: Response) => <Product[]>response.json());

  }
  removeproduct(proid: Number): Observable<Product[]> {
    return this.http.delete("http://localhost:3000/prod/" + proid).map((response: Response) => <Product[]>response.json()).catch(this.handleError);
  }
  handleError(error: Response) {
    console.error(error);
    return Observable.throw(error);
  }

  updatepro(pro: Product): Observable<Product[]> {
    return this.http.put(("http://localhost:3000/prod/" + pro.id), pro).map((response: Response) => <Product[]>response.json()).catch(this.handleError);
  }
  edit(pro: Product): void {
    this.showProduct.emit(pro);

  }
  
}
