import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductserveService } from '../productserve.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
})
export class ProductComponent implements OnInit {
  products:Product[];
  product:Product=new Product();
  prod:Product=new Product();
  count:number=0;;
  constructor(private ProductserveService:ProductserveService) { }

  ngOnInit() {
 
    this.ProductserveService.getProduct().subscribe((productData)=> {this.products=productData,this.count=this.products.length});
   
  
  }
  remove(proid:Number):void{
    console.log("remove button"+proid);
    this.ProductserveService.removeproduct(proid).subscribe((proData)=> this.ProductserveService.getProduct().subscribe((data)=>this.products=data),
    (error)=>{
      console.error(error);
    })
    
  }
  update(pro:Product):void{
          console.log("component");
        this.ProductserveService.edit(pro);
           
          
  }
  sortId():any{this.products.sort(function abc(a,b)
    {
    
        return a.id-b.id;
    }
    )};
    
    sortPrice():any{this.products.sort(function abc(a,b)
        {
            return a.price-b.price;
        }
        )};

}
