export class Users {
username:string
password:string
}
